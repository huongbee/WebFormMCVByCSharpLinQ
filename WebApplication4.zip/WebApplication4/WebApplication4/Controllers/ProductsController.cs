﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class ProductsController : Controller
    {
        // GET: Products

        NWDataContext db;
        public ProductsController()
        {
            db = new NWDataContext();
        }
        public ActionResult Index()//hien thi DS SP
        {
            var p = db.Products.Select(s => s).ToList();
            return View(p);
        }

        //Hien thi DS San pham + ten loai san pham
        public ActionResult List()//hien thi DS SP + ten loai san pham
        {
            // p = db.Products.Select(s => s).ToList();
            List<ProductModel> productModel = db.Products.Select
                (s => new ProductModel
                {
                    ProductID = s.ProductID,
                    ProductName = s.ProductName,
                    UnitPrice = s.UnitPrice,
                    QuantityPerUnit = s.QuantityPerUnit,
                    CompanyName = s.Supplier.CompanyName,
                    CategoryID = s.CategoryID,
                    CategoryName = s.Category.CategoryName,
                    SupplierID = s.SupplierID,
                    UnitsInStock = s.UnitsInStock,
                    UnitsOnOrder = s.UnitsOnOrder,
                    ReorderLevel = s.ReorderLevel,
                    Discontinued = s.Discontinued
                }).OrderByDescending(p=>p.ProductID).ToList();
            return View(productModel);
        }
        //Tạo 1 model chua du lieu cua 2 bang

        //details
        public ActionResult Details(int id)//chi tiet DS SP
        {
            Product p = db.Products.Where(s => s.ProductID == id).FirstOrDefault();
            var productModel = new ProductModel();
            productModel.ProductID = p.ProductID;
            productModel.ProductName = p.ProductName;
            productModel.QuantityPerUnit = p.QuantityPerUnit;
            productModel.UnitPrice = p.UnitPrice;
            productModel.CategoryID = p.CategoryID;
            productModel.SupplierID = p.SupplierID;
            productModel.UnitsOnOrder = p.UnitsOnOrder;
            productModel.UnitsInStock = p.UnitsInStock;
            productModel.ReorderLevel = p.ReorderLevel;
            productModel.Discontinued = p.Discontinued;
            productModel.CompanyName = p.Supplier.CompanyName;
            productModel.CategoryName = p.Category.CategoryName;
            productModel.CategoryList = db.Categories.ToList();
            productModel.SupplierList = db.Suppliers.ToList();
            return View(productModel);
           // var p = db.Products.Where(m => m.ProductID == id).FirstOrDefault();
            //return View(p);
        }

        //Them Sp
        [HttpGet]
        public ActionResult Create()
        {
            var p = new ProductModel {
                CategoryList =db.Categories.ToList(),
                SupplierList = db.Suppliers.ToList()
            };
            return View(p);
        }
        [HttpPost]
        public ActionResult Create(ProductModel productModel)//chi tiet DS SP
        {
            if (productModel.ProductName == null || productModel.ProductName == "")
            {
                TempData["ErrorMessage"] = "Vui lòng nhập tên sản phẩm";
                return RedirectToAction("Result");
            }
            var p = new Product();
            p.ProductID = productModel.ProductID;
            p.ProductName = productModel.ProductName;
            p.UnitPrice = productModel.UnitPrice;
            p.QuantityPerUnit = productModel.QuantityPerUnit;
            p.CategoryID = productModel.CategoryID;
            p.ReorderLevel = productModel.ReorderLevel;
            p.SupplierID = productModel.SupplierID;
            p.UnitsInStock = productModel.UnitsInStock;
            p.UnitsOnOrder = productModel.UnitsOnOrder;
            p.Discontinued = productModel.Discontinued;
            db.Products.InsertOnSubmit(p);
            db.SubmitChanges();

            return RedirectToAction("List");
        }

        //Sửa SP
        [HttpGet]//hien thi chi tiet Sp, không hien thị mã SP
        public ActionResult Edit(int id)
        {
            //Lay Sp
            Product p = db.Products.Where(s => s.ProductID == id).FirstOrDefault();
            var productModel = new ProductModel();
            productModel.ProductID = p.ProductID;
            productModel.ProductName = p.ProductName;
            productModel.QuantityPerUnit = p.QuantityPerUnit;
            productModel.UnitPrice = p.UnitPrice;
            productModel.CategoryID = p.CategoryID;
            productModel.SupplierID = p.SupplierID;
            productModel.UnitsOnOrder = p.UnitsOnOrder;
            productModel.UnitsInStock = p.UnitsInStock;
            productModel.ReorderLevel = p.ReorderLevel;
            productModel.Discontinued = p.Discontinued;
            productModel.CategoryList = db.Categories.ToList();
            productModel.SupplierList = db.Suppliers.ToList();

            return View(productModel);
        }
        [HttpPost]//hien thi chi tiet Sp, không hien thị mã SP
        public ActionResult Edit(ProductModel productModel)
        {
            var p = db.Products.Where(s => s.ProductID == productModel.ProductID).FirstOrDefault();
            p.ProductID = productModel.ProductID;
            p.ProductName = productModel.ProductName;
            p.UnitPrice = productModel.UnitPrice;
            p.QuantityPerUnit = productModel.QuantityPerUnit;
            p.CategoryID = productModel.CategoryID;
            p.ReorderLevel = productModel.ReorderLevel;
            p.SupplierID = productModel.SupplierID;
            p.UnitsInStock = productModel.UnitsInStock;
            p.UnitsOnOrder = productModel.UnitsOnOrder;
            p.Discontinued = productModel.Discontinued;
            db.SubmitChanges();
            return RedirectToAction("List");
        }

        //Xóa SP

        //hien thi chi tiet Sp, không hien thị mã SP
        public ActionResult Delete(int id)
        {
            Product p = db.Products.Where(s => s.ProductID == id).FirstOrDefault();
            var productModel = new ProductModel();
            productModel.ProductID = p.ProductID;
            productModel.ProductName = p.ProductName;
            productModel.QuantityPerUnit = p.QuantityPerUnit;
            productModel.UnitPrice = p.UnitPrice;
            productModel.CategoryID = p.CategoryID;
            productModel.SupplierID = p.SupplierID;
            productModel.UnitsOnOrder = p.UnitsOnOrder;
            productModel.UnitsInStock = p.UnitsInStock;
            productModel.ReorderLevel = p.ReorderLevel;
            productModel.Discontinued = p.Discontinued;
            productModel.CategoryList = db.Categories.ToList();
            productModel.SupplierList = db.Suppliers.ToList();
            return View(productModel);
        }

        [HttpPost]//hien thi chi tiet Sp, không hien thị mã SP
        public ActionResult Delete(int id, ProductModel p1)
        {
            try
            {
                Product p = db.Products.FirstOrDefault(s => s.ProductID == id);

                db.Products.DeleteOnSubmit(p);
                db.SubmitChanges();
                return RedirectToAction("List");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Không thể xóa sẩn phẩm, Vui lòng thử lại sau";
                return RedirectToAction("Result");
            }
        }
        public ActionResult Result()
        {
            var errMsg = TempData["ErrorMessage"] as string;
            return View();
            //check errMsg value do whatever you want now as needed
        }
    }
}