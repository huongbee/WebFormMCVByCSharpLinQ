﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class OrderController : Controller
    {
        
        NWDataContext db;
        public OrderController()
        {
            db = new NWDataContext();
        }
        // GET: Order
        public ActionResult List()
        {
            //var p = db.Orders
            //   .GroupJoin(
            //       db.Order_Details.ToList(),
            //       order => order.OrderID,
            //       detail => detail.OrderID,
            //       (order, Od) => new
            //       {
            //           order.OrderID,
            //           order.OrderDate,
            //           order.EmployeeID,
            //           SumQuantity = Od.Sum(x => x.Quantity),
            //           SumPrice = Od.Sum(x => x.Quantity * x.UnitPrice)
            //       }
            //   )
            //   .ToList();
            //var p = db.Orders
            //    .Join(
            //        db.Order_Details.ToList(),
            //        order => order.OrderID,
            //        detail => detail.OrderID,
            //        (order, detail) => new
            //        {
            //            order.OrderID,
            //            order.OrderDate,
            //            order.EmployeeID,
            //            detail.Quantity,
            //            detail.UnitPrice
            //        }
            //    )
            //    .GroupBy(item => new
            //    {
            //        item.OrderID,
            //        item.OrderDate,
            //        item.EmployeeID
            //    })
            //    .Select(s => new
            //    {
            //        OrderID = s.Key.OrderID,
            //        OrderDate = s.Key.OrderDate,
            //        EmployeeID = s.Key.EmployeeID,
            //        SumQuantity = s.Sum(x => x.Quantity),
            //        SumPrice = s.Sum(x => x.Quantity * x.UnitPrice)
            //    })
            //    .ToList();

            List<OrdersModel> p = (
                from order in db.Orders
                join detail in db.Order_Details
                    on order.OrderID equals detail.OrderID
                group new { order, detail } by new
                {
                    order.OrderID,
                    order.OrderDate,
                    order.EmployeeID
                } into temp
                select new OrdersModel
                {
                    OrderID = temp.Key.OrderID,
                    OrderDate = temp.Key.OrderDate,
                    EmployeeID = temp.Key.EmployeeID,
                    SumQuantity = temp.Sum(x => x.detail.Quantity),
                    SumPrice = temp.Sum(x => x.detail.Quantity * x.detail.UnitPrice)
                }
            ).ToList();
            return View(p);
        }
    }
}