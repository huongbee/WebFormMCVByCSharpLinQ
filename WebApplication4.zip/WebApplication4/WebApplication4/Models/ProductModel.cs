﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.Models
{
    public class ProductModel
    {
		public int ProductID { get; set; }

		public string ProductName { get; set; }

		public System.Nullable<int> SupplierID { get; set; }

		public System.Nullable<int> CategoryID { get; set; }

		public string QuantityPerUnit { get; set; }

		public System.Nullable<decimal> UnitPrice { get; set; }

		public System.Nullable<short> UnitsInStock { get; set; }

		public System.Nullable<short> UnitsOnOrder { get; set; }

		public System.Nullable<short> ReorderLevel { get; set; }

		public bool Discontinued { get; set; }

		//Them thuoc tinh
		public string CategoryName { get; set; }
        public string CompanyName { get; set; }

        public IEnumerable<Category> CategoryList { get; set; }
        public IEnumerable<Supplier> SupplierList { get; set; }
        public IEnumerable<ProductModel> ProductModelList { get; set; }


	}
}